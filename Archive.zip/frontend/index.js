import {doAThing} from "./temp/other";

console.log("Hi");

doAThing("Hello");