const doAThing = (param) => {
    console.log(`Logging ${param} from within other`)
}

export {doAThing}